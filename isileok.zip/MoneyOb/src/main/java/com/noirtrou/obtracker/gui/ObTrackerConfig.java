package com.noirtrou.obtracker.gui;

public class ObTrackerConfig {
    public static boolean minionVisible = true;
    public static boolean islandLevelVisible = true;
}