package com.noirtrou.obtracker.mixin;

import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin pour intercepter directement les paquets de titre du serveur
 * Plus fiable que l'interception des méthodes HUD
 */
@Mixin(ClientPlayNetworkHandler.class)
public class TitlePacketHandlerMixin {
    
    static {
        System.out.println("[ObTracker] TitlePacketHandlerMixin chargé avec succès !");
    }
    
    /**
     * Intercepte tous les paquets de titre (approche générique)
     */
    @Inject(method = "onTitle", at = @At("HEAD"), require = 0)
    private void onTitlePacket(TitleS2CPacket packet, CallbackInfo ci) {
        try {
            System.out.println("[ObTracker] DEBUG: Paquet TitleS2CPacket intercepté");
            // Le contenu sera traité par le TitleCaptureMixin lors de l'affichage
        } catch (Exception e) {
            System.err.println("[ObTracker] Erreur lors de l'interception du paquet: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Intercepte les paquets de sous-titre
     */
    @Inject(method = "onSubtitle", at = @At("HEAD"), require = 0)  
    private void onSubtitlePacket(SubtitleS2CPacket packet, CallbackInfo ci) {
        try {
            System.out.println("[ObTracker] DEBUG: Paquet SubtitleS2CPacket intercepté");
        } catch (Exception e) {
            System.err.println("[ObTracker] Erreur lors de l'interception du paquet sous-titre: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Intercepte les paquets d'overlay/action bar
     */
    @Inject(method = "onOverlayMessage", at = @At("HEAD"), require = 0)
    private void onOverlayMessagePacket(OverlayMessageS2CPacket packet, CallbackInfo ci) {
        try {
            System.out.println("[ObTracker] DEBUG: Paquet OverlayMessageS2CPacket intercepté");
        } catch (Exception e) {
            System.err.println("[ObTracker] Erreur lors de l'interception du paquet overlay: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
