package com.noirtrou.obtracker.mixin;

import com.noirtrou.obtracker.listeners.TitleListener;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin pour capturer les titres affichés dans le HUD
 * Intercepte les méthodes de titre de InGameHud pour une capture directe des paquets
 */
@Mixin(InGameHud.class)
public class TitleCaptureMixin {
    
    static {
        System.out.println("[ObTracker] TitleCaptureMixin chargé avec succès !");
    }
    
    /**
     * Capture l'affichage des titres principaux
     */
    @Inject(method = "setTitle", at = @At("HEAD"))
    private void onTitleSet(Text title, CallbackInfo ci) {
        try {
            System.out.println("[ObTracker] DEBUG: Mixin onTitleSet appelé avec: " + (title != null ? title.getString() : "null"));
            if (title != null) {
                TitleListener.onTitleReceived(title);
            }
        } catch (Exception e) {
            System.err.println("[ObTracker] Erreur lors de la capture du titre: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Capture l'affichage des sous-titres
     */
    @Inject(method = "setSubtitle", at = @At("HEAD"))
    private void onSubtitleSet(Text subtitle, CallbackInfo ci) {
        try {
            System.out.println("[ObTracker] DEBUG: Mixin onSubtitleSet appelé avec: " + (subtitle != null ? subtitle.getString() : "null"));
            if (subtitle != null) {
                TitleListener.onSubtitleReceived(subtitle);
            }
        } catch (Exception e) {
            System.err.println("[ObTracker] Erreur lors de la capture du sous-titre: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Capture l'affichage des messages overlay (action bar)
     */
    @Inject(method = "setOverlayMessage", at = @At("HEAD"))
    private void onOverlayMessageSet(Text message, boolean tinted, CallbackInfo ci) {
        try {
            System.out.println("[ObTracker] DEBUG: Mixin onOverlayMessageSet appelé avec: " + (message != null ? message.getString() : "null"));
            if (message != null) {
                TitleListener.onActionBarReceived(message);
            }
        } catch (Exception e) {
            System.err.println("[ObTracker] Erreur lors de la capture de l'action bar: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
